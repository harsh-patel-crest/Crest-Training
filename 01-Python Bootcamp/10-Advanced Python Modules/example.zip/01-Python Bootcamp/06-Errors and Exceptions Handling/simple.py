def func():
    '''
    This is a simple function
    '''
    a=10
    b=20

    print(f"a is {a} and b is {b}")

func()